from flask import Flask, render_template, request
from linklist import LinkedList
from stack import Stack
from flask import Flask, render_template, request, session
import re

ll = LinkedList()

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')
@app.route('/works', methods=['GET', 'POST'])
def works():
    return render_template('works.html')
@app.route('/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString')
        result = input_string.upper()

    return render_template('touppercase.html', result=result)
@app.route('/works/area/circle', methods=['GET', 'POST'])
def acircle():
    result = None
    if request.method == 'POST':
        radius = request.form.get('radius', '')
        result = int(radius)*3.14*int(radius)
    return render_template('circle.html', result=result)
@app.route('/works/area/triangle', methods=['GET', 'POST'])
def atriangle():
    result = None

    if request.method == 'POST':
        base = float(request.form.get('base'))
        height = float(request.form.get('height'))

        result = 0.5 * base * height

    return render_template('triangle.html', result=result)


# @app.route('/areaOfcirle', methods=['GET', 'POST'])
# def areaOfcirle():
#     result = None
#     name=request.get('name','')
#     print(name)
#     if request.method == 'POST':
#         input_string = request.form.get('inputradius', '')
#         result = int(input_string) * int(input_string) * 3.14
#     return render_template('areaCircle.html', result=result)
ll.insert_at_end(10)
ll.insert_at_end(20)
ll.insert_at_end(30)


@app.route("/linkedlist", methods=["GET", "POST"])
def linkedlist():
    message = ""

    if request.method == "POST":
        action = request.form.get("action")
        
        if action == "insert_beginning":
            value = int(request.form["value"])
            ll.insert_at_beginning(value)
            message = f"{value} inserted at the beginning."
        elif action == "insert_end":
            value = int(request.form["value"])
            ll.insert_at_end(value)
            message = f"{value} inserted at the end."

        elif action == "search":
            value = int(request.form["value"])
            if ll.search(value):
                message = f"{value} was found in the list."
            else:
                message = f"{value} was not found in the list."

        elif action == "remove_beginning":
            removed = ll.remove_beginning()

            if removed is not None:
                message = f"{removed} was removed from the beginning."
            else:
                message = "The list is empty."

        elif action == "remove_end":
            removed = ll.remove_at_end()

            if removed is not None:
                message = f"{removed} was removed from the end."
            else:
                message = "The list is empty."
        elif action == "remove":
            value = int(request.form["value"])
            removed = ll.remove_at(value)

            if removed is not None:
                message = f"{removed} was removed from the list."
            else:
                message = f"{value} was not found."

        elif action == "insert_after":
            after = int(request.form["after"])
            value = int(request.form["value"])

            result = ll.insert_after(after, value)

            if result is not None:
                message = f"{value} was inserted after {after}."
            else:
                message = f"{after} was not found."
    values = []
    current = ll.head

    while current:
        values.append(current.data)
        current = current.next

    return render_template(
        "linkedlist.html",
        values=values,
        message=message
    )
@app.route('/contact')
def contact():
    return render_template('contact.html')

order_of_precedence = {
    '+': 1,
    '-': 1,
    '*': 2,
    '/': 2,
    '^': 3,
}

allowed_symbols = '()+-*/^'


def is_operand(token):
    if not token:
        return False
    return token.isdigit() or (len(token) == 1 and token.isalpha())


def split_into_tokens(expression):
    if expression is None:
        raise ValueError("Please enter an infix expression.")

    text = ''.join(ch for ch in expression if not ch.isspace())
    if not text:
        raise ValueError("Please enter an infix expression.")

    tokens = []
    buffer = ''
    previous = None  

    for ch in text:
        if ch.isalnum():
            buffer += ch
            previous = 'operand'
            continue

        if ch not in allowed_symbols:
            raise ValueError(f"Invalid character: {ch}")

        if buffer:
            tokens.append(buffer)
            buffer = ''
            previous = 'operand'

        if ch in '+-' and previous in (None, 'operator', '('):
            raise ValueError("Unary plus and minus are not supported.")

        tokens.append(ch)
        if ch in '()':
            previous = ch
        else:
            previous = 'operator'

    if buffer:
        tokens.append(buffer)

    if not tokens:
        raise ValueError("Please enter a valid infix expression.")

    return tokens


def convert_infix_to_postfix(expression):
    tokens = split_into_tokens(expression)

    ops = Stack()
    output = Stack()

    for token in tokens:
        if is_operand(token):
            output.push(token)

        elif token == '(':
            ops.push(token)

        elif token == ')':
            while not ops.is_empty() and ops.peek() != '(':
                output.push(ops.pop())
            if ops.is_empty():
                raise ValueError("Mismatched parentheses.")
            ops.pop()

        elif token in order_of_precedence:
            while (not ops.is_empty()
                   and ops.peek() != '('
                   and order_of_precedence[ops.peek()] >= order_of_precedence[token]):
                output.push(ops.pop())
            ops.push(token)

        else:
            raise ValueError(f"What i do?: {token}")

    while not ops.is_empty():
        leftover = ops.pop()
        if leftover == '(':
            raise ValueError("Mismatched parentheses.")
        output.push(leftover)

    output_tokens = []
    while not output.is_empty():
        output_tokens.append(output.pop())
    output_tokens.reverse()
    return ''.join(output_tokens)

@app.route("/stack", methods=["GET", "POST"])
def stack_page():
    expression = ""
    result = ""
    error = ""

    if request.method == "POST":
        expression = request.form.get("expression", "")

        try:
            result = convert_infix_to_postfix(expression)
        except ValueError as e:
            error = str(e)

    return render_template(
        "stack.html",
        expression=expression,
        result=result,
        error=error
    )

#dequeue and queue

app.secret_key = 'your-secret-key'
class Queue:
    def __init__(self):
        self.items = []
    def enqueue(self, data):
        self.items.append(data)
    def dequeue(self):
        if self.is_empty():
            return None
        return self.items.pop(0)
    def is_empty(self):
        return len(self.items) == 0
    def display(self):
        return self.items.copy()

@app.route('/queue', methods=['GET', 'POST'])
def queue_page():
    q = Queue()
    q.items = session.get('queue_items', [])

    message = ""
    error = ""

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'enqueue':
            value = request.form.get('item', '').strip()

            if value:
                q.enqueue(value)
                session['queue_items'] = q.display()
                message = f"Enqueued: {value}"
            else:
                error = "enter anything or something."

        elif action == 'dequeue':
            removed = q.dequeue()

            if removed is None:
                error = "empty queue"
            else:
                session['queue_items'] = q.display()
                message = f"Dequeued: {removed}"

    return render_template(
        'queue.html',
        queue_items=q.display(),
        message=message,
        error=error
    )




if __name__ == "__main__":
    app.run(debug=True)



