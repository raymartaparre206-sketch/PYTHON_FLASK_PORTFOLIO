from flask import Flask, render_template, request
from linklist import LinkedList

ll = LinkedList()

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')
@app.route('/works', methods=['GET', 'POST'])
def works():
    return render_template('works.html')
@app.route('/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString')
        result = input_string.upper()

    return render_template('touppercase.html', result=result)
@app.route('/works/area/circle', methods=['GET', 'POST'])
def acircle():
    result = None
    if request.method == 'POST':
        radius = request.form.get('radius', '')
        result = int(radius)*3.14*int(radius)
    return render_template('circle.html', result=result)
@app.route('/works/area/triangle', methods=['GET', 'POST'])
def atriangle():
    result = None

    if request.method == 'POST':
        base = float(request.form.get('base'))
        height = float(request.form.get('height'))

        result = 0.5 * base * height

    return render_template('triangle.html', result=result)


# @app.route('/areaOfcirle', methods=['GET', 'POST'])
# def areaOfcirle():
#     result = None
#     name=request.get('name','')
#     print(name)
#     if request.method == 'POST':
#         input_string = request.form.get('inputradius', '')
#         result = int(input_string) * int(input_string) * 3.14
#     return render_template('areaCircle.html', result=result)
ll.insert_at_end(10)
ll.insert_at_end(20)
ll.insert_at_end(30)


@app.route("/linkedlist", methods=["GET", "POST"])
def linkedlist():
    message = ""

    if request.method == "POST":
        action = request.form.get("action")
        
        if action == "insert_beginning":
            value = int(request.form["value"])
            ll.insert_at_beginning(value)
            message = f"{value} inserted at the beginning."
        elif action == "insert_end":
            value = int(request.form["value"])
            ll.insert_at_end(value)
            message = f"{value} inserted at the end."

        elif action == "search":
            value = int(request.form["value"])

            if ll.search(value):
                message = f"{value} was found in the list."
            else:
                message = f"{value} was not found in the list."

        elif action == "remove_beginning":
            removed = ll.remove_beginning()

            if removed is not None:
                message = f"{removed} was removed from the beginning."
            else:
                message = "The list is empty."

        elif action == "remove_end":
            removed = ll.remove_at_end()

            if removed is not None:
                message = f"{removed} was removed from the end."
            else:
                message = "The list is empty."
        elif action == "remove":
            value = int(request.form["value"])
            removed = ll.remove_at(value)

            if removed is not None:
                message = f"{removed} was removed from the list."
            else:
                message = f"{value} was not found."

        elif action == "insert_after":
            after = int(request.form["after"])
            value = int(request.form["value"])

            result = ll.insert_after(after, value)

            if result is not None:
                message = f"{value} was inserted after {after}."
            else:
                message = f"{after} was not found."
    values = []
    current = ll.head

    while current:
        values.append(current.data)
        current = current.next

    return render_template(
        "linkedlist.html",
        values=values,
        message=message
    )

@app.route('/contact')
def contact():
    return render_template('contact.html')
if __name__ == "__main__":
    app.run(debug=True)
